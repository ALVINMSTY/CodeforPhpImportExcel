<html>
<head>
</head>
<body>
<center>
<h2>PHP Upload Excel file with multiple Sheets and save the data in MySQL table</h2>
<form action="upload_form.php" method="post" enctype="multipart/form-data">
Select file <input type="file" name="file_upload"/>
<input type="submit" value="Upload"/>
</form>
</center>
</body>
</html>