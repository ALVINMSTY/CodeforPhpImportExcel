<?php  
$hostname='localhost';
$username='root';
$password='';
$database='test';
 ?>